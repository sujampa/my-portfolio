import React, { useState } from 'react';
import { Menu, X, Mail, MapPin, Github, Linkedin, Code2, Gamepad2, Brain, Palette } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import { ProjectCard } from './components/ProjectCard';
import { SkillCard } from './components/SkillCard';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    setFormData({ name: '', email: '', message: '' });
  };

  const projects = [
    {
      title: '3D RPG Game',
      description: 'A tactical RPG with character animations, quest systems, and open-world mechanics in Unity.',
      icon: <Gamepad2 className="w-8 h-8 text-blue-500" />,
      color: '#3B82F6',
    },
    {
      title: 'Library Management System',
      description: 'Spring Boot + MySQL web app for managing library records.',
      icon: <Code2 className="w-8 h-8 text-blue-500" />,
      color: '#10B981',
    },
    {
      title: 'Project Tracker',
      description: 'A student project tracking platform with authentication.',
      icon: <Brain className="w-8 h-8 text-blue-500" />,
      color: '#8B5CF6',
    },
    {
      title: 'Web Design Portfolio',
      description: 'A modern, responsive website showcasing UI/UX skills and interactive design elements.',
      icon: <Palette className="w-8 h-8 text-blue-500" />,
      color: '#EC4899',
    },
  ];

  const skills = [
    {
      category: 'Game Dev',
      items: ['Unity', 'Animation', 'AI', 'Mechanics'],
    },
    {
      category: 'Software',
      items: ['Java', 'Spring Boot', 'Hibernate', 'SQL', 'JavaScript'],
    },
    {
      category: 'AI & Data',
      items: ['Machine Learning', 'Data Analytics', 'Optimization'],
    },
    {
      category: 'UX/UI',
      items: ['Adobe XD', 'Interactive Design', 'Responsive UI'],
    },
  ];

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="fixed w-full bg-gray-900/95 backdrop-blur-sm z-50 border-b border-gray-800">
        <nav className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <a href="#" className="text-2xl font-bold text-blue-500">Surya Jampa</a>
            
            {/* Mobile Menu Button */}
            <button
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X /> : <Menu />}
            </button>

            {/* Desktop Navigation */}
            <div className="hidden md:flex space-x-8">
              <a href="#about" className="hover:text-blue-500 transition-colors">About</a>
              <a href="#skills" className="hover:text-blue-500 transition-colors">Skills</a>
              <a href="#projects" className="hover:text-blue-500 transition-colors">Projects</a>
              <a href="#education" className="hover:text-blue-500 transition-colors">Education</a>
              <a href="#contact" className="hover:text-blue-500 transition-colors">Contact</a>
            </div>
          </div>

          {/* Mobile Navigation */}
          <AnimatePresence>
            {isMenuOpen && (
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="md:hidden"
              >
                <div className="flex flex-col space-y-4 py-4">
                  <a href="#about" className="hover:text-blue-500 transition-colors">About</a>
                  <a href="#skills" className="hover:text-blue-500 transition-colors">Skills</a>
                  <a href="#projects" className="hover:text-blue-500 transition-colors">Projects</a>
                  <a href="#education" className="hover:text-blue-500 transition-colors">Education</a>
                  <a href="#contact" className="hover:text-blue-500 transition-colors">Contact</a>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="min-h-screen flex items-center justify-center bg-[url('https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80')] bg-cover bg-center bg-no-repeat">
        <div className="absolute inset-0 bg-gray-900/80"></div>
        <div className="relative container mx-auto px-6 text-center">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-5xl md:text-7xl font-bold mb-4"
          >
            Surya Jampa
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-xl md:text-2xl text-gray-300"
          >
            Designer | Developer | Game Developer | AI Enthusiast
          </motion.p>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-gray-800">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold mb-12 text-center">About Me</h2>
          <div className="max-w-3xl mx-auto text-gray-300 text-lg leading-relaxed">
            <p>
              I am a passionate game developer with expertise in Unity, C#, Java, and UX design.
              I specialize in AI, backend systems, and immersive gaming experiences.
            </p>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 bg-gray-900">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold mb-12 text-center">Skills & Expertise</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {skills.map((skillGroup, index) => (
              <SkillCard key={index} {...skillGroup} />
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 bg-gray-800">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold mb-12 text-center">Featured Projects</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {projects.map((project, index) => (
              <ProjectCard key={index} {...project} />
            ))}
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section id="education" className="py-20 bg-gray-900">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold mb-12 text-center">Education</h2>
          <div className="max-w-3xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="bg-gray-800 p-8 rounded-lg"
            >
              <h3 className="text-2xl font-semibold mb-2">B.Tech in Computer Science</h3>
              <p className="text-blue-500 mb-2">KL University</p>
              <p className="text-gray-300 mb-2">Specialization: UI/UX Design & Game Development</p>
              <p className="text-gray-400">2022 - 2026</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gray-800">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold mb-12 text-center">Get in Touch</h2>
          <div className="max-w-4xl mx-auto bg-gray-900 rounded-2xl overflow-hidden shadow-xl">
            <div className="grid grid-cols-1 md:grid-cols-2">
              {/* Contact Info */}
              <div className="bg-blue-600 p-12 flex flex-col justify-center">
                <h3 className="text-2xl font-bold mb-8">Contact Information</h3>
                <div className="space-y-6">
                  <div className="flex items-center space-x-4">
                    <Mail className="w-6 h-6" />
                    <a href="mailto:jampasurya4@gmail.com" className="hover:text-blue-200 transition-colors">
                      jampasurya4@gmail.com
                    </a>
                  </div>
                  <div className="flex items-center space-x-4">
                    <MapPin className="w-6 h-6" />
                    <span>Unguturu, India</span>
                  </div>
                  <div className="flex space-x-4 mt-8">
                    <a
                      href="http://linkedin.com/in/surya-jampa-9babb328a"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:text-blue-200 transition-colors"
                    >
                      <Linkedin className="w-6 h-6" />
                    </a>
                    <a
                      href="https://github.com/surya__jampa"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:text-blue-200 transition-colors"
                    >
                      <Github className="w-6 h-6" />
                    </a>
                  </div>
                </div>
              </div>

              {/* Contact Form */}
              <div className="p-12">
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-2">
                      Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg focus:outline-none focus:border-blue-500 transition-colors"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg focus:outline-none focus:border-blue-500 transition-colors"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-2">
                      Message
                    </label>
                    <textarea
                      id="message"
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      rows={4}
                      className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg focus:outline-none focus:border-blue-500 transition-colors"
                      required
                    ></textarea>
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold py-3 px-6 rounded-lg transition-colors"
                  >
                    Send Message
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-gray-900 border-t border-gray-800">
        <div className="container mx-auto px-6 text-center text-gray-400">
          <p>© 2025 Surya Jampa | All Rights Reserved</p>
        </div>
      </footer>
    </div>
  );
}

export default App;