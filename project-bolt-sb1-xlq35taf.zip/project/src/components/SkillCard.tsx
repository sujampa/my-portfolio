import React from 'react';
import { motion } from 'framer-motion';

interface SkillCardProps {
  category: string;
  items: string[];
}

export function SkillCard({ category, items }: SkillCardProps) {
  const categoryImages = {
    'Game Dev': 'https://images.unsplash.com/photo-1552820728-8b83bb6b773f?auto=format&fit=crop&q=80&w=500',
    'Software': 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&q=80&w=500',
    'AI & Data': 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&q=80&w=500',
    'UX/UI': 'https://images.unsplash.com/photo-1545235617-9465d2a55698?auto=format&fit=crop&q=80&w=500'
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      whileHover={{ scale: 1.02 }}
      className="bg-gray-800 rounded-lg overflow-hidden"
    >
      <motion.div 
        className="h-48 relative overflow-hidden"
        whileHover={{ scale: 1.1 }}
        transition={{ duration: 0.3 }}
      >
        <img
          src={categoryImages[category as keyof typeof categoryImages]}
          alt={category}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/40 to-transparent" />
        <h3 className="absolute bottom-4 left-6 text-2xl font-bold text-white">{category}</h3>
      </motion.div>
      
      <div className="p-6">
        <ul className="space-y-2">
          {items.map((item, index) => (
            <motion.li
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className="flex items-center text-gray-300"
            >
              <span className="w-2 h-2 bg-blue-500 rounded-full mr-3" />
              {item}
            </motion.li>
          ))}
        </ul>
      </div>
    </motion.div>
  );
}