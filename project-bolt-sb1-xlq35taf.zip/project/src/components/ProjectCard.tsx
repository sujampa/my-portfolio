import React from 'react';
import { motion } from 'framer-motion';

interface ProjectCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  color: string;
}

export function ProjectCard({ title, description, icon }: ProjectCardProps) {
  const projectImages = {
    '3D RPG Game': 'https://images.unsplash.com/photo-1538582709238-0a503bd5ae04?auto=format&fit=crop&q=80&w=500',
    'Library Management System': 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?auto=format&fit=crop&q=80&w=500',
    'Project Tracker': 'https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?auto=format&fit=crop&q=80&w=500',
    'Web Design Portfolio': 'https://images.unsplash.com/photo-1522542550221-31fd19575a2d?auto=format&fit=crop&q=80&w=500'
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="group relative bg-gray-900 rounded-xl overflow-hidden"
    >
      <motion.div
        className="h-64 relative overflow-hidden"
        whileHover={{ scale: 1.05 }}
        transition={{ duration: 0.3 }}
      >
        <img
          src={projectImages[title as keyof typeof projectImages]}
          alt={title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/60 to-transparent" />
      </motion.div>

      <div className="absolute bottom-0 w-full p-6 transform translate-y-4 transition-transform duration-300 group-hover:translate-y-0">
        <div className="flex items-center mb-3">
          <div className="p-2 bg-blue-500 rounded-lg">
            {icon}
          </div>
          <h3 className="text-xl font-bold ml-3 text-white">{title}</h3>
        </div>
        
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
          className="text-gray-300 text-sm"
        >
          {description}
        </motion.p>

        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          whileInView={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.3 }}
          className="mt-4"
        >
          <button className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
            Learn More
          </button>
        </motion.div>
      </div>
    </motion.div>
  );
}